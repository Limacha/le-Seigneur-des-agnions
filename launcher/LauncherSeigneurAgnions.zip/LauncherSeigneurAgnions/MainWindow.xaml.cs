﻿using System;
using System.IO;
using System.IO.Compression;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using System.Windows.Media;
using Microsoft.Win32;

namespace LauncherSeigneurAgnions
{
    public partial class MainWindow : Window
    {
        private string installPath = "";

        public MainWindow()
        {
            InitializeComponent();

            // Charger le chemin d'installation
            installPath = Properties.Settings.Default.InstallPath;

            // Vérifier si le jeu est installé ou non
            CheckGameVersion();
        }

        // Méthode pour ouvrir le sélecteur de dossier pour le chemin d'installation
        private void ChooseInstallPath_Click(object sender, RoutedEventArgs e)
        {
            // Ouvrir un sélecteur de dossier (FileDialog)
            var dialog = new OpenFileDialog
            {
                CheckFileExists = false, // Permet de choisir un dossier, pas un fichier
                CheckPathExists = true,
                ValidateNames = false,
                FileName = "Sélectionner un dossier"
            };

            if (dialog.ShowDialog() == true)
            {
                installPath = System.IO.Path.GetDirectoryName(dialog.FileName);
                InstallPathTextBox.Text = installPath;
            }
        }

        // Méthode appelée lors du clic sur le bouton principal
        private void MainButton_Click(object sender, RoutedEventArgs e)
        {
            string exePath = Path.Combine(installPath, "GAME", "Le Seigneur Des Agnions.exe");

            if (File.Exists(exePath))
            {
                // Lancer le jeu
                System.Diagnostics.Process.Start(exePath);
            }
            else
            {
                MainButton.Content = "Télécharger";
                // Si le jeu n'est pas installé, proposer l'installation
                ShowPanel(DownloadPanel);
            }
        }

        // Gérer l'affichage des panels avec animations
        private void ShowPanel(Grid panel)
        {
            if (SettingsPanel.Visibility == Visibility.Visible && panel != SettingsPanel)
                HidePanel(SettingsPanel);
            if (PatchNotesPanel.Visibility == Visibility.Visible && panel != PatchNotesPanel)
                HidePanel(PatchNotesPanel);
            if (DownloadPanel.Visibility == Visibility.Visible && panel != DownloadPanel)
                HidePanel(DownloadPanel);

            panel.Visibility = Visibility.Visible;
            DoubleAnimation fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.2));
            ScaleTransform scale = new ScaleTransform(0.8, 0.8);
            panel.RenderTransform = scale;
            DoubleAnimation scaleUp = new DoubleAnimation(0.8, 1, TimeSpan.FromSeconds(0.2));

            panel.BeginAnimation(OpacityProperty, fadeIn);
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleUp);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleUp);
        }

        // Cacher un panel avec animation
        private void HidePanel(Grid panel)
        {
            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.2));
            fadeOut.Completed += (s, e) => panel.Visibility = Visibility.Collapsed;
            panel.BeginAnimation(OpacityProperty, fadeOut);
        }

        // Démarrer le téléchargement
        private void StartDownload_Click(object sender, RoutedEventArgs e)
        {
            // Fermer la popup de téléchargement après avoir démarré le téléchargement
            HidePanel(DownloadPanel);  // Ferme la popup DownloadPanel

            if (string.IsNullOrEmpty(installPath))
            {
                MessageBox.Show("Veuillez sélectionner un chemin d'installation.");
                return;
            }

            // Simulation de téléchargement (copie depuis un fichier local)
            string zipFilePath = Path.Combine(installPath, "GAME.zip");
            string extractPath = installPath;

            // Simulation de téléchargement, on copie le fichier ZIP (tu peux remplacer par un vrai téléchargement)
            File.Copy(@"O:\Unity\GAME.zip", zipFilePath, true);

            // Décompression
            ZipFile.ExtractToDirectory(zipFilePath, extractPath);
            File.Delete(zipFilePath);

            // Sauvegarder le chemin d'installation
            Properties.Settings.Default.InstallPath = installPath;
            Properties.Settings.Default.Save();

            // Modifier le bouton en "Jouer"
            MainButton.Content = "Jouer";
        }


        // Vérifier si le jeu est installé
        private void CheckGameVersion()
        {
            string exePath = Path.Combine(installPath, "GAME", "Le Seigneur Des Agnions.exe");

            if (File.Exists(exePath))
            {
                MainButton.Content = "Jouer";
            }
            else
            {
                MainButton.Content = "Télécharger";
            }
        }

        // Méthode pour fermer le panneau de téléchargement
        private void CloseDownloadPanel_Click(object sender, RoutedEventArgs e)
        {
            HidePanel(DownloadPanel);
        }

        // Gestion des panels
        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            ShowPanel(SettingsPanel);
        }

        private void PatchNotesButton_Click(object sender, RoutedEventArgs e)
        {
            ShowPanel(PatchNotesPanel);
        }

        private void CloseSettings_Click(object sender, RoutedEventArgs e)
        {
            HidePanel(SettingsPanel);
        }

        private void ClosePatchNotes_Click(object sender, RoutedEventArgs e)
        {
            HidePanel(PatchNotesPanel);
        }
    }
}
