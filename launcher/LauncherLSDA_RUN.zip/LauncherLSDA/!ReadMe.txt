-- FR --  

Pour lancer le jeu, cliquez sur "LauncherLSDA.bat".  
Si cela ne fonctionne pas, veuillez installer le fichier "Net8".  
Veuillez laisser TOUS les fichiers dans le dossier "LauncherLSDA".  
Si les fichiers n'y sont plus, le launcher risque de ne pas fonctionner.  

-- EN --  

To launch the game, click on "LauncherLSDA.bat".  
If it doesn't work, please install the "Net8" file.  
Please leave ALL the files in the "LauncherLSDA" folder.  
If the files are missing, the launcher may not work properly.  

-- NE --  

Om het spel te starten, klik op "LauncherLSDA.bat".  
Als het niet werkt, installeer dan het bestand "Net8".  
Laat ALLE bestanden in de map "LauncherLSDA" staan.  
Als de bestanden ontbreken, werkt de launcher mogelijk niet goed.  

-- GE --  

Um das Spiel zu starten, klicken Sie auf "LauncherLSDA.bat".  
Falls es nicht funktioniert, installieren Sie bitte die Datei "Net8".  
Bitte lassen Sie ALLE Dateien im Ordner "LauncherLSDA".  
Falls die Dateien fehlen, könnte der Launcher nicht richtig funktionieren.  

-- JP --  

ゲームを起動するには、「LauncherLSDA.bat」をクリックしてください。  
動作しない場合は、「Net8」ファイルをインストールしてください。  
「LauncherLSDA」フォルダー内のすべてのファイルをそのままにしてください。  
ファイルが不足していると、ランチャーが正しく動作しない可能性があります。  

-- RU --  

Чтобы запустить игру, нажмите "LauncherLSDA.bat".  
Если не работает, установите файл "Net8".  
Оставьте ВСЕ файлы в папке "LauncherLSDA".  
Если файлы отсутствуют, лаунчер может не работать.  
