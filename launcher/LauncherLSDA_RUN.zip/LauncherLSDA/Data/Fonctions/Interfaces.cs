﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Media;
using System.Windows;
using LauncherLSDA;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Windows.Input;

namespace LauncherLSDA.Fonctions
{
    internal class Interfaces
    {
        private MainWindow main;
        public Interfaces(MainWindow mainWindow)
        {
            main = mainWindow;
        }

        /* -------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------- */

        /* Afficher panel */
        public void ShowPanel(Grid panel)
        {
            if (main.SettingsPanel.Visibility == Visibility.Visible && panel != main.SettingsPanel)
                HidePanel(main.SettingsPanel);
            if (main.PatchNotesPanel.Visibility == Visibility.Visible && panel != main.PatchNotesPanel)
                HidePanel(main.PatchNotesPanel);
            if (main.DownloadPanel.Visibility == Visibility.Visible && panel != main.DownloadPanel)
                HidePanel(main.DownloadPanel);
            if (main.DeletePanel.Visibility == Visibility.Visible && panel != main.DeletePanel)
                HidePanel(main.DeletePanel);

            panel.Visibility = Visibility.Visible;
            DoubleAnimation fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.2));
            ScaleTransform scale = new ScaleTransform(0.8, 0.8);
            panel.RenderTransform = scale;
            DoubleAnimation scaleUp = new DoubleAnimation(0.8, 1, TimeSpan.FromSeconds(0.2));

            panel.BeginAnimation(UIElement.OpacityProperty, fadeIn);
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleUp);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleUp);
        }
        /* Cacher panel */
        public void HidePanel(Grid panel)
        {
            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.2));
            fadeOut.Completed += (s, e) => panel.Visibility = Visibility.Collapsed;
            panel.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }


        /* -------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------- */


        /* Animations du button download / Maj et barre de chargement */
        public void AnimateButtonFadeOut(UIElement element, Action onCompleted)
        {
            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.3));
            fadeOut.Completed += (s, e) =>
            {
                element.Visibility = Visibility.Collapsed;
                onCompleted?.Invoke();
            };
            element.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }
        public void AnimateButtonFadeIn(UIElement element)
        {
            element.Visibility = Visibility.Visible;
            DoubleAnimation fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.3));
            element.BeginAnimation(UIElement.OpacityProperty, fadeIn);
        }
        public void AnimateGridFadeOut(UIElement element, Action onCompleted)
        {
            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.3));
            fadeOut.Completed += (s, e) =>
            {
                element.Visibility = Visibility.Collapsed;
                onCompleted?.Invoke();
            };
            element.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }
        public void AnimateGridFadeIn(UIElement element)
        {
            element.Visibility = Visibility.Visible;
            DoubleAnimation fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.3));
            element.BeginAnimation(UIElement.OpacityProperty, fadeIn);
        }


        /* -------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------- */


        public async void PatchNoteRefresh()
        {
            string url = "https://leseigneurdesagnions.handdor.eu/";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string pageContent = await client.GetStringAsync(url);

                    // 🟢 Récupérer le titre du patch note (Version)
                    Match matchTitle = Regex.Match(pageContent, @"<h1>\s*Patch Note\s*<b>(V\d+\.\d+)</b>\s*</h1>");
                    if (matchTitle.Success)
                    {
                        main.PatchNoteTitre.Text = $"Patch Note {matchTitle.Groups[1].Value}";
                    }

                    // 🟢 Récupérer toutes les <p> du patch note
                    MatchCollection matches = Regex.Matches(pageContent, @"<p id=""PatchNote"">(.*?)<\/p>");

                    // Mettre à jour les TextBlocks si les infos existent
                    if (matches.Count > 0) main.PatchNoteInfo1.Text = matches[0].Groups[1].Value;
                    if (matches.Count > 1) main.PatchNoteInfo2.Text = matches[1].Groups[1].Value;
                    if (matches.Count > 2) main.PatchNoteInfo3.Text = matches[2].Groups[1].Value;
                    if (matches.Count > 3) main.PatchNoteInfo4.Text = matches[3].Groups[1].Value;
                    if (matches.Count > 4) main.PatchNoteInfo5.Text = matches[4].Groups[1].Value;
                }
            }
            catch (Exception ex)
            {
                Notifier("Attention !", "Erreur lors de la récupération du patch note");
            }
        }


        /* -------------------------------------------------------------------------------------------------------------- */
        /* -------------------------------------------------------------------------------------------------------------- */


        public async Task Notifier(string titre, string message)
        {
            main.TitreNotif.Text = titre;
            main.TexteNotif.Text = message;

            // Animation d'entrée (glissement du bas vers le haut)
            DoubleAnimation slideIn = new DoubleAnimation
            {
                From = 150,  // Position de départ (hors de l'écran)
                To = 0,      // Position finale
                Duration = TimeSpan.FromSeconds(0.3),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };

            DoubleAnimation fadeIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromSeconds(0.3)
            };

            main.NotificationZone.RenderTransform = new TranslateTransform();
            main.NotificationZone.Visibility = Visibility.Visible;
            main.NotificationZone.Opacity = 1;

            main.NotificationZone.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideIn);
            main.NotificationZone.BeginAnimation(UIElement.OpacityProperty, fadeIn);

            // Attendre 5 secondes
            await Task.Delay(5000);

            // Animation de sortie (glissement vers le bas et disparition)
            DoubleAnimation slideOut = new DoubleAnimation
            {
                From = 0,
                To = 150,
                Duration = TimeSpan.FromSeconds(0.3),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
            };

            DoubleAnimation fadeOut = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.3)
            };

            slideOut.Completed += (s, e) => main.NotificationZone.Visibility = Visibility.Collapsed;

            main.NotificationZone.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideOut);
            main.NotificationZone.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }

        public async Task FermerNotificationFCT()
        {
            DoubleAnimation fadeOut = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromSeconds(0.3)
            };

            DoubleAnimation slideOut = new DoubleAnimation
            {
                From = 0,
                To = 150,
                Duration = TimeSpan.FromSeconds(0.3),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
            };

            slideOut.Completed += (s, e) => main.NotificationZone.Visibility = Visibility.Collapsed;

            main.NotificationZone.RenderTransform.BeginAnimation(TranslateTransform.YProperty, slideOut);
            main.NotificationZone.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }

    }
}
