﻿using LauncherLSDA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;
using IWshRuntimeLibrary;

namespace LauncherLSDA.Fonctions
{
    internal class Telechargements
    {
        private Stopwatch stopwatch = new Stopwatch();
        private MainWindow main;
        Interfaces UI;
        public Telechargements(MainWindow mainWindow)
        {
            main = mainWindow;
            UI = new Interfaces(main);
        }

        /* Véréfication de la version du jeux */
        public async Task CheckGameVersion(string installPath)
        {
            string exePath = Path.Combine(installPath, "LeSeigneurDesAgnions", "Le Seigneur Des Agnions.exe");
            string versionFilePath = Path.Combine(installPath, "LeSeigneurDesAgnions", "version.txt");
            string urlVersion = "https://leseigneurdesagnions.handdor.eu/";

            // Vérifier si le jeu est installé
            if (System.IO.File.Exists(exePath))
            {
                // Vérifier si le fichier version.txt existe
                if (System.IO.File.Exists(versionFilePath))
                {
                    main.ButRacouci.Opacity = 1;
                    main.ButRacouci.Visibility = Visibility.Visible;

                    string localVersion = System.IO.File.ReadAllText(versionFilePath).Trim();
                    string onlineVersion = await GetOnlineVersion(urlVersion);

                    if (onlineVersion != null)
                    {

                        // Comparer les versions
                        if (localVersion != onlineVersion)
                        {
                            if (main.AutoUpdate.IsChecked == true) 
                            {
                                string zipFilePath = Path.Combine(installPath, "GAME.zip");
                                string extractPath = installPath;

                                UpdateGame(installPath, extractPath, zipFilePath);
                            } else
                            {
                                main.MainButtonTXT.Text = "Mettre à jour";
                                main.MainButtonIMG.Source = new BitmapImage(new Uri("pack://application:,,,/IMG/downloadIcon.png"));

                                main.UninstallButt.Opacity = 1;
                                main.UninstallButt.Visibility = Visibility.Visible;
                            }

                        }
                        else
                        {
                            main.MainButtonTXT.Text = "Jouer";
                            main.MainButtonIMG.Source = new BitmapImage(new Uri("pack://application:,,,/IMG/playIcon.png"));

                            main.UninstallButt.Opacity = 1;
                            main.UninstallButt.Visibility = Visibility.Visible;
                        }
                    }
                }
            }
            else
            {
                main.MainButtonTXT.Text = "Télécharger";
                main.MainButtonIMG.Source = new BitmapImage(new Uri("pack://application:,,,/IMG/downloadIcon.png"));

                main.UninstallButt.Opacity = 0;
                main.UninstallButt.Visibility = Visibility.Collapsed;
                
                main.ButRacouci.Opacity = 0;
                main.ButRacouci.Visibility = Visibility.Collapsed;
            }
        }
        public async Task<string> GetOnlineVersion(string url)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string pageContent = await client.GetStringAsync(url);
                    Match match = Regex.Match(pageContent, @"<h1>\s*Patch Note\s*<b>(V\d+\.\d+)</b>\s*</h1>");

                    if (match.Success)
                    {
                        return match.Groups[1].Value;
                    }
                }
            }
            catch (Exception ex)
            {
                UI.Notifier("Attention !", "Erreur lors de la récupération de la version en ligne");
            }

            return null;
        }

        public async Task DownloadProtocol(string installPath, string extractPath, string zipFilePath)
        {
            stopwatch.Restart();

            Uri Uri = new Uri("http://leseigneurdesagnions.handdor.eu/GAME.zip");
            using (WebClient client = new WebClient())
            {
                client.DownloadFileCompleted += new AsyncCompletedEventHandler(Completed);
                client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(DownloadProgress);
                await client.DownloadFileTaskAsync(Uri, zipFilePath);
            }


            // Décompression
            ZipFile.ExtractToDirectory(zipFilePath, extractPath);
            System.IO.File.Delete(zipFilePath);

            // Sauvegarder le chemin d'installation
            Properties.Settings.Default.InstallPath = installPath;
            Properties.Settings.Default.Save();

            CheckGameVersion(installPath);

            // racourci
            if(main.ShortCut.IsChecked == true)
            {
                string exePath = Path.Combine(installPath, "LeSeigneurDesAgnions", "Le Seigneur Des Agnions.exe");

                // Chemin de l'icône (relative ou absolue)
                string iconPath = @"./IMG/seigneur_agneau.ico";  // Modifie ce chemin selon où se trouve l'icône

                // Obtenir le chemin du bureau de l'utilisateur
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                // Chemin complet du raccourci sur le bureau
                string shortcutPath = Path.Combine(desktopPath, "Le Seigneur Des Agnions.lnk");

                // Création du raccourci
                CreateShortcut(exePath, shortcutPath, iconPath);
            }
        }
        /// <summary>
        /// Racourcis
        /// </summary>
        /// <param name="targetPath"></param>
        /// <param name="shortcutPath"></param>
        public void CreateShortcut(string targetPath, string shortcutPath, string iconPath)
        {
            try
            {
                // Vérifie si le fichier cible existe
                if (!System.IO.File.Exists(targetPath))
                {
                    throw new FileNotFoundException("Le fichier cible n'existe pas.", targetPath);
                }

                // Crée un objet WshShell
                WshShell shell = new WshShell();
                IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutPath);

                // Configure le raccourci
                shortcut.TargetPath = targetPath;
                shortcut.WorkingDirectory = Path.GetDirectoryName(targetPath);
                shortcut.IconLocation = System.IO.File.Exists(iconPath) ? iconPath : targetPath;
                shortcut.Save();

                UI.Notifier("Notification", "Le raccourci a bien été créé.");
            }
            catch (Exception ex)
            {
                UI.Notifier("Erreur", $"Erreur lors de la création du raccourci : {ex.Message}");
            }
        }

        public void Completed(object sender, AsyncCompletedEventArgs e)
        {
            stopwatch.Stop();

            UI.AnimateGridFadeOut(main.DownloadProgressGrid, () =>
            {
                UI.AnimateButtonFadeIn(main.MainButton);
                UI.AnimateButtonFadeIn(main.UninstallButt);
            });

            if (e.Cancelled == true)
            {
                UI.Notifier("Attention !", "Le téléchargement a été annulé.");
            }
            else
            {
                UI.Notifier("Notification", "Le téléchargement terminé avec succes.");
            }
        }
        private void DownloadProgress(object sender, DownloadProgressChangedEventArgs e)
        {
            // Mise à jour de la barre de progression
            main.DownloadProgressBar.Value = e.ProgressPercentage;

            // Calcul de la vitesse de téléchargement
            double bytesIn = e.BytesReceived;
            double totalBytes = e.TotalBytesToReceive;

            double speed = bytesIn / (stopwatch.Elapsed.TotalSeconds + 1); // Évite la division par zéro
            string speedText = speed > 1048576
                ? $"{(speed / 1048576).ToString("0.00")} Mo/s"
                : $"{(speed / 1024).ToString("0.00")} Ko/s";

            // Calcul du temps restant estimé
            double bytesLeft = totalBytes - bytesIn;
            double estimatedTime = speed > 0 ? bytesLeft / speed : 0;
            TimeSpan timeRemaining = TimeSpan.FromSeconds(estimatedTime);

            string timeText = timeRemaining.TotalSeconds > 0
                ? $"{timeRemaining.Minutes:D2}:{timeRemaining.Seconds:D2}"
                : "--:--";

            // Mise à jour des labels dans l'UI
            main.DownloadSpeedText.Text = $"Vitesse: {speedText}";
            main.TimeRemainingText.Text = $"Temps restant: {timeText}";
        }







        public async Task UpdateGame(string installPath, string extractPath, string zipFilePath)
        {
            UI.AnimateButtonFadeOut(main.MainButton, () =>
            {
                UI.AnimateGridFadeIn(main.DownloadProgressGrid);
            });

            UninstallGame(installPath);

            DownloadProtocol(installPath, extractPath, zipFilePath);

            CheckGameVersion(installPath);

            UI.Notifier("Notification", "Mise a jour terminée.");
        }








        /* Fonction Pour Désinstaller le jeux */
        public void UninstallGame(string installPath)
        {
            string exePath = Path.Combine(installPath, "LeSeigneurDesAgnions", "Le Seigneur Des Agnions.exe");
            string shortcutPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Le Seigneur Des Agnions.lnk");

            if (System.IO.File.Exists(exePath))
            {
                try
                {
                    // Vérifie si le raccourci existe et le supprime
                    if (System.IO.File.Exists(shortcutPath))
                    {
                        System.IO.File.Delete(shortcutPath);
                    }

                    // Supprime le dossier du jeu
                    Directory.Delete(installPath + @"\LeSeigneurDesAgnions", true);
                    UI.Notifier("Notification", "Le jeu a bien été désinstallé et le raccourci supprimé.");
                }
                catch (IOException ex)
                {
                    UI.Notifier("Attention !", ex.Message);
                }
            }
            else
            {
                UI.Notifier("Attention !", "Impossible de désinstaller, le jeu n'est pas installé.");
            }
        }
    }
}
